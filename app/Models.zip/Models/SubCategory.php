<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'sub_category';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'sub_category_id';

    /**
     * The "type" of the auto-incrementing ID.
     *
     * @var string
     */
    protected $keyType = 'integer';
    public function SubSubCategory()
    {
        $obj=$this->hasManyThrough('App\Models\SubCategory', 'App\Models\SubSubCategory','sub_category_id','sub_category_id','sub_category_id')
        ->join("category as b", function($join)
        {
            $join->on("sub_category.category_id","b.category_id");
        },  null, null, "left outer")
        ->select("b.name as categoryName","sub_category.*","sub_sub_category.*");
        //->join('category as b', 'sub_category.category_id', '=', 'b.category_id');
        return $obj;

        //return $this->hasManyThrough('App\Models\SubCategory', 'App\Models\SubSubCategory','category_id','sub_category_id','category_id');
    }
}
