<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessWorkingDays extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'business_working_days';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'business_working_days_id';

    /**
     * The "type" of the auto-incrementing ID.
     *
     * @var string
     */
    protected $keyType = 'integer';

}
