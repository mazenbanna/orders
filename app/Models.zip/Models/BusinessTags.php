<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessTags extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'business_tags';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'business_tags_id';

    /**
     * The "type" of the auto-incrementing ID.
     *
     * @var string
     */
    protected $keyType = 'integer';

}
