<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class Business extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'business';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'business_id';

    /**
     * The "type" of the auto-incrementing ID.
     *
     * @var string
     */
    protected $keyType = 'integer';


    public function __construct()
    {
        return $this->images();
    }

    public function images()
    {
        return $this->hasMany('App\Models\BusinessImage','business_id','business_id');
    }
    // public function likes_number()
    // {
    //     $obj=$this->hasMany('App\Models\ShopPostLike','shop_post_id','shop_post_id');//->select(DB::raw('count(*) as number'));
    //     return $obj;//sizeof($obj);
    // }

    public function business_region()
    {
        return $this->belongsTo('App\Models\Region','region_id','region_id');
    }
    public function business_package()
    {
        return $this->belongsTo('App\Models\Package','package_id','package_id');
    }
    // public function program_main_image()
    // {
    //     return $this->belongsTo('App\Models\ProgramImages','programs_id','programs_id')->where('is_main','1');
    // }
    public function business_category()
    {
        $obj=$this->hasMany('App\Models\BusinessCategory','business_id','business_id')
        ->join('category', 'category.category_id', '=', 'business_category.category_id');
        return $obj;
    }
    public function business_tags()
    {
        $obj=$this->hasMany('App\Models\BusinessTags','business_id','business_id')
        ->join('tags', 'tags.tags_id', '=', 'business_tags.tags_id');
        return $obj;
    }
    public function business_working_days()
    {
        $obj=$this->hasMany('App\Models\BusinessWorkingDays','business_id','business_id')
        ->join('days', 'days.days_id', '=', 'business_working_days.days_id');
        return $obj;
    }

}
